---
name: sap-product-explainer
description: >-
  Explains any SAP product in plain language to any SAP employee, regardless of their technical background. Delivers a quick overview first, then offers a detailed breakdown on request. Use when the user says "Explain [product] to me", "How does [product] work?", "What is [product]?", "Tell me about [SAP product]", "Give me an overview of [product]", or mentions any SAP product name followed by a question about what it does or how it works.
allowed-tools: web_search
metadata:
  version: 1.0.0
  tags: sap products knowledge explainer portfolio overview cx btp
---

# SAP Product Explainer

Explain any SAP product in plain language to any SAP employee, regardless of their role or technical background. Always search for the latest information — never rely on training knowledge alone.

## Trigger Conditions

Activate when the user says:
- "Explain [product] to me"
- "How does [product] work?"
- "What is [product]?"
- "Tell me about [SAP product]"
- "Give me an overview of [product]"

If no specific product is mentioned, ask: "Which SAP product would you like me to explain?"

---

## Step 1 — Search for Product Information

Make the following web searches in a **single message with 3 tool calls** (they are independent and can run in parallel):

- Search A: `[product name] SAP product overview site:sap.com OR site:help.sap.com`
- Search B: `[product name] SAP Store site:store.sap.com`
- Search C: `[product name] SAP Chief Product Officer CPO 2025 2026`

Wait for all 3 results before proceeding to Step 2.

---

## Step 2 — Deliver the Quick Overview

Use this exact structure:

---

**📦 What it is**
Two plain-language sentences explaining what the product does. Write as if explaining to a colleague who has never heard of it. No jargon, no acronyms without explanation.
Include the SAP Store link on the same line: [View on SAP Store](url) — use the URL found in Search B. If not found on SAP Store, link to the product page on sap.com instead.

**🗂 Where it fits in SAP's Portfolio**
Before including this section, assess the complexity of the product hierarchy:
- If SHORT and CLEAN (3–4 levels maximum, unambiguous placement) → include the text tree below.
- If LONG or COMPLEX (many branches, sub-products, or unclear placement) → SKIP this section here and write: *"Portfolio placement is shown in the detailed overview."*

When included, format as:
```
SAP Portfolio
└── [Suite or Layer, e.g. Cloud ERP / Business Technology Platform]
    └── [Product Family, e.g. SAP S/4HANA / SAP BTP]
        └── [Product Name]
```

**🏢 Line of Business**
State which Line of Business (LoB) this product belongs to (e.g. Finance, HR, Supply Chain, Procurement, Customer Experience, Technology Platform).

**👔 Chief Product Officer (CPO)**
Name of the CPO responsible for this product, sourced from Search C. If uncertain or not found, write: *"Based on latest available information: [Name]. Please verify on SAP.com for the most current details."*

---

After delivering the Quick Overview, always end with:
> "Would you like to have a detailed overview?"

---

## Step 3 — Detailed Overview (only if user confirms)

If the user says yes, run two additional searches in a **single message with 2 tool calls**:

- Search D: `[product name] SAP demo OR product tour OR free trial 2025 2026`
- Search E: `[product name] SAP components modules integrations`

Wait for both results, then deliver the full Detailed Overview using this exact structure:

---

**📦 What it is**
Same two plain-language sentences as the Quick Overview.
[View on SAP Store](url)

**🗂 Where it fits in SAP's Portfolio**
Always include the full hierarchy here, regardless of depth or complexity.
```
SAP Portfolio
└── [Suite or Layer]
    └── [Product Family]
        └── [Product Name]
            ├── [Sub-component 1, if applicable]
            └── [Sub-component 2, if applicable]
```

**⚙️ Key Capabilities**
Exactly 5 capabilities as bullet points. Each: one clear sentence, plain language, no jargon.
- [Capability 1]
- [Capability 2]
- [Capability 3]
- [Capability 4]
- [Capability 5]

**🎬 Demo**
If a demo, free trial, or product tour is found in Search D: one plain-language sentence describing what it covers, followed by the link.
Example: *"See how SAP S/4HANA streamlines financial close in this 10-minute product tour."* → [Watch Demo](url)
If nothing is found, write: *"No public demo currently available."*

**👤 Who typically uses it**
List the roles or personas who use this product day-to-day (e.g. CFO, HR Business Partner, Supply Chain Planner, IT Administrator).

**🏢 Line of Business**
Same as Quick Overview.

**👔 Chief Product Officer (CPO)**
Same as Quick Overview.

**🔗 Components & Integrations**
Key modules, sub-components, and integration points with other SAP or third-party products. Short bulleted list sourced from Search E.
- [Component / Integration 1]
- [Component / Integration 2]
- [Component / Integration 3]

---

## Important Guidelines

- **Always search first** — never answer from memory. SAP's product portfolio, leadership, and store listings change frequently.
- **Plain language** — write for any SAP employee, from HR to engineering. Avoid internal jargon and unexplained acronyms.
- **Link accuracy** — only include URLs found in search results. Never fabricate links.
- **CPO accuracy** — leadership changes. Always source from the most recent search result and flag uncertainty.
- **Store link** — always try store.sap.com first. Fall back to sap.com product page if not found.
- **Tone** — professional but approachable. Warm, direct, and free of corporate stiffness.