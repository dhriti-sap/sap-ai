# Changelog

All notable changes to the SAP Product Explainer skill are documented here.
This project follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and [Semantic Versioning](https://semver.org/).

---

## [1.0.0] — 2026-10-05

### Added
- Initial release of the SAP Product Explainer skill
- **Quick Overview** mode: What it is (2-liner + SAP Store link), Portfolio tree, Line of Business, CPO
- **Detailed Overview** mode (on user request): Key capabilities (5 bullets), Demo link, Who typically uses it, Components & Integrations
- Parallel web search — 3 concurrent searches for Quick Overview (SAP.com/Help Portal, SAP Store, CPO), 2 for Detailed Overview (demo, components)
- Conditional portfolio tree — included in Quick Overview only if hierarchy is compact (≤4 levels); deferred to Detailed Overview otherwise
- Adaptive output flow — Quick Overview always delivered first; Detailed Overview only on confirmation ("Would you like to have a detailed overview?")
- CPO accuracy guidelines — always sourced from latest web search with uncertainty flagging
- Store link fallback — falls back to sap.com product page if SAP Store listing not found
- GitHub-ready supporting files: README.md, CHANGELOG.md, LICENSE

---

## [Unreleased]

### Planned
- Support for SAP partner product explanations
- Multi-language output support
- Integration with SAP Learning Hub for course recommendations
